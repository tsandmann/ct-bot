Da ich es nicht hinbekomme, die Bilder in den Patch zu integrieren, 
liegen sie als Extra-Dateien bei. Die Bilder m�ssen von Hand in das Verzeichnis 
ctSim/ctSim/View/LCDisplay kopiert werden.
Danach sollte das Projekt in Eclipse aktualisiert werden, damit die Bilder in das 
bin Verzeichnis kopiert wird.
